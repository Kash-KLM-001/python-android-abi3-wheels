import sys
_v = sys.version_info[:2]
if _v >= (3, 14):
    from ._py314 import tokenizers as _ext
elif _v >= (3, 13):
    from ._py313 import tokenizers as _ext
else:
    raise ImportError('this wheel needs Python 3.8 or newer')
_skip = {'__name__', '__doc__', '__package__', '__loader__',
         '__spec__', '__file__', '__builtins__'}
globals().update({k: v for k, v in vars(_ext).items()
                  if k not in _skip})
